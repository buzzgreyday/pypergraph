BASE_URL_TEMPLATE = "https://l{layer}-lb-{network}.constellationnetwork.io"
BLOCK_EXPLORER_URL_TEMPLATE = "https://be-{network}.constellationnetwork.io"