DEFAULT_L0_BASE_URL = 'https://l0-lb-mainnet.constellationnetwork.io'
DEFAULT_L1_BASE_URL = 'https://l1-lb-mainnet.constellationnetwork.io'
BLOCK_EXPLORER_URL = 'https://block-explorer.constellationnetwork.io'