# Nodebot
mnemo = "multiply angle perfect verify behind sibling skirt attract first lift remove fortune"
to_address = "DAG5WLxvp7hQgumY7qEFqWZ9yuRghSNzLddLbxDN"
from_address = "DAG0zJW14beJtZX2BY2KA9gLbpaZ8x6vgX4KVPVX"