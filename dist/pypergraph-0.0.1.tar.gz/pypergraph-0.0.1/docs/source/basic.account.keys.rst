Account Keys
============

.. admonition:: Constellation Key Trio

    Accounts consists of a cryptographic key trio comprising:

    - **Private Key**: A secure cryptographic element used to authenticate ownership and authorize transactions.
      Required for signing transactions and messages. **Treat as sensitive information**.
    - **Public Key**: Derived from the private key, serves as a network identifier for node authentication and
      signature verification in trust relationships.
    - **Address**: Public wallet identifier generated from cryptographic keys. Shareable for receiving transactions
      while maintaining private key confidentiality.

-----

Create New Secrets
^^^^^^^^^^^^^^^^^^

Mnemonic Hierarchical Deterministic Key
---------------------------------------

.. code-block:: python

    from pypergraph.keystore import KeyStore

    keystore = KeyStore()
    mnemonic_phrase = keystore.generate_mnemonic()  # Generate BIP-39 compliant seed phrase


Private Key
-----------

.. code-block:: python

    from pypergraph.keystore import KeyStore

    keystore = KeyStore()
    private_key = keystore.generate_private_key()


Login with Existing Key
^^^^^^^^^^^^^^^^^^^^^^^

Seed Phrase
-----------

.. code-block:: python

    from pypergraph.account import DagAccount

    account = DagAccount()
    account.login_with_seed_phrase("abandon abandon ...")  # Provide 12-word mnemonic
    account.logout()

Private Key
-----------

.. code-block:: python

    account.login_with_private_key("private_key_here")
    account.logout()

Public Key (Read-only)
----------------------
.. note::
    Functionalities such as signing transactional data requiring secrets not supported.

.. code-block:: python

    account.login_with_public_key("public_key_here")
    account.logout()

-----

Get Account Keys
^^^^^^^^^^^^^^^^

After logging the following values are available.

DAG Address
-----------

.. code-block:: python

    dag_address = account.address

Public Key (Node ID)
--------------------

.. code-block:: python

    public_key = account.public_key

Private Key
-----------
.. note::
    The private key is not available if logged in with public key only.

.. code-block:: python

    private_key = account.private_key

