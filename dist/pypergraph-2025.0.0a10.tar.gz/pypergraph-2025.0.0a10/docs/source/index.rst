.. pypergraph documentation master file, created by
   sphinx-quickstart on Sun Jan  5 16:50:08 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Pypergraph Documentation
========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   basics
   installation
   modules