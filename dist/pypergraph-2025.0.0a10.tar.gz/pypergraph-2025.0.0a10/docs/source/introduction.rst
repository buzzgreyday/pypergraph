Introduction
============

Pypergraph is a Python package that enables secure wallet functionalities and interaction with Constellation Network APIs, in Python.

.. caution::

  The package is currently in the early alpha state and not intended for production.

**Wish to contribute?** Please reach out on `GitHub <https://github.com/buzzgreyday>`_.
